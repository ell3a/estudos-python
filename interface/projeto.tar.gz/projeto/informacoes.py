nome = '\nSistema de Gerenciamento de Biblioteca\n'

v = '0.0'
d = 'abril de 2021'
a = 'Leandro Vieira dos Santos'
i = 'Sistema simples para o gerenciamento de bibliotecas pessois.'

texto = f'{nome}\n\nVersão do programa: {v}, data: {d}\nCriação e desenvolvimento: {a}\n{i}\n\n'