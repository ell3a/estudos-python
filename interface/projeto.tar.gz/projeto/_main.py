try:
    from tkinter import *
except:
    from Tkinter import *

import gerenciamento as ger
import cadastro as cad
import sobre as sob

ger.abertura()

class Janela:

    def __init__(self,toplevel):

        self.toplevel = toplevel
        self.toplevel.title('Gerenciamento de Biblioteca')

        self.topo=Frame(toplevel)
        self.cent=Frame(toplevel)
        self.base=Frame(toplevel)
        self.topo.pack(expand=TRUE,anchor=NW,padx=15,pady=15)
        self.cent.pack(expand=TRUE,anchor=W,padx=15,pady=15)
        self.base.pack(expand=TRUE,anchor=SE,padx=15,pady=15)

        self.brelatorio=Button(self.topo,text='Relatórios')
        self.brelatorio.pack(side=LEFT)

        self.bsobre=Button(self.topo,text='?')
        self.bsobre.bind("<Button-1>", self.sobre)
        self.bsobre.pack(side=LEFT)

        self.bcadastrar=Button(self.cent,text='Cadastrar')
        self.bcadastrar.bind("<Button-1>", self.cadastrar)
        self.bcadastrar['background'] = '#C5D1CF'
        self.bcadastrar['font']=('Verdana','30')
        self.bcadastrar['fg']='black'
        self.bcadastrar['width']=15
        self.bcadastrar['height']=1
        self.bcadastrar.pack()

        self.bsair=Button(self.base,text='Sair')
        self.bsair.bind("<Button-1>", self.sair)
        self.bsair.pack(side=LEFT)

    def sair(self, event):
        ger.fechamento()
        sys.exit()

    def sobre(self, event):
        sob.sobre()

    def cadastrar(self, event):
        cad.cadastrar()


raiz=Tk()
Janela(raiz)
raiz.geometry('750x450')
raiz.mainloop()